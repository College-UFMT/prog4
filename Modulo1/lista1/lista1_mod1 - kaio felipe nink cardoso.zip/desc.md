## Lista 1 - Módulo 1

1. Crie uma página HTML com os seguintes requisitos:
    * A página inicial deve conter título e uma lista (ordenada ou não ordenada) com pelo menos 3 itens
    * Cada um dos 3 itens deve ser um hyperlink para uma página diferente, também criada por você
    * Cada uma destas páginas deverá conter uma imagem e alguma informação relacionada
    * Cada uma das páginas também deverá conter um hyperlink com a palavra “Voltar” com ligação para a página inicial

Observações:
* Salve tudo numa única pasta, com o seu nome
* Compacte esta pasta e envie o arquivo pelo AVA (requisito para pontuação)
* O tema da página é livre