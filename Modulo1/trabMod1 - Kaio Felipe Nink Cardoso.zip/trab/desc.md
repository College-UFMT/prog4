## Trabalho - Módulo 1

### Apresentação
<p> É comum encontrar sites de professores que utilizam de HTML simples para exibirem seu portifólio de trabalho, contendo suas informações de contato, interesses de pesquisa, publicações, etc Clicando aqui você pode ver alguns exemplos nesse sentido. </p>
<p>O trabalho consiste na criação de uma página HTML contendo seu portifólio. Pode conter desde seus interesses de pesquisa, informações de contato, trabalhos já realizados, indicações de links para conteúdos que gostaria de divulgar, etc.</p>


### Requisitos
<p>O importante é que se utilize dos conceitos básicos de HTML apresentados neste módulo (exceto pela utilização de formulários, pois exigiriam programação back-end ainda não vista). Mesmo assim, é livre a utilização de tecnologias ainda não apresentadas mas que sejam conhecidas e dominadas, para algum incremento gráfico desejado.</p>
<p>Ao final, pretendo divulgar as páginas de vocês numa lista (manifeste-se caso você prefira que o seu não apareça).</p>